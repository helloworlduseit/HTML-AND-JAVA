import java.util.Scanner;
public class ModifiedPerson {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter phone number: ");
		long phoneNumber = sc.nextLong();
		Person2_3 person2_3 = new Person2_3("Divya", "Bharathi", 'F',phoneNumber);
		person2_3.dispDetailPerson();
}
}
