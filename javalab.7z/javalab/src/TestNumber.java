
public class TestNumber {

	public static void main(String[] args) {
		int userNumber = Integer.parseInt(args[0]);
		if(userNumber<0){
			System.out.println("Number "+userNumber+" is Negavtive.");
		}
		else{
			System.out.println("Number "+userNumber+" is Positive.");
		}

	}

}
