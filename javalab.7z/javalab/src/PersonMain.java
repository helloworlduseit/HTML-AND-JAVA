
public class PersonMain {

	public static void main(String[] args) {
		Person1 person1 = new Person1("Divya", "Bharathi", 'F');
		
		System.out.println("Person Details:");
		System.out.println("------------------------------");
		System.out.println("First Name: "+person1.getFirstName());
		System.out.println("Last Name: "+person1.getLastName());
		System.out.println("Gender: "+person1.getGender());
	}

}
