import java.util.Scanner;

enum Gender
{
	Male('M'),Female('F');
	private final char value;
	private Gender(char value)
	{this.value=value;
}
	public char value()
	{
		return value;
	}
}
public class PersonMain2_5 {

	public static void main(String[] args) {
		Gender genderr= Gender.Female;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter phone number: ");
		long phoneNumber = sc.nextLong();
		Person2_5 person2_5 = new Person2_5("Divya", "Bharathi", genderr.value(),phoneNumber);
		person2_5.dispDetailPerson();
		}

	}


