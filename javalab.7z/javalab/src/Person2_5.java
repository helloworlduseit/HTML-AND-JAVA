
public class Person2_5 {
	private String firstName;
	private String lastName;
	private char gender;
	private long phone;
	
		
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public char getGender()
	{
		return gender;
	}
	public long getPhone()
	{
		return phone;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
	public void setPhone(long phone)
	{
		this.phone=phone;
	}
	
	public Person2_5()
	{
		firstName="Unknown";
		lastName="Unknown";
		gender=' ';
	}
	public Person2_5(String firstName, String lastName, char gender,long phone) {
		setFirstName(firstName);
		setLastName(lastName);
		setGender(gender);
		setPhone(phone);
	}
	void dispDetailPerson(){
		System.out.println("Person Details:");
		System.out.println("------------------------------");
		System.out.println("First Name: "+getFirstName());
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+getPhone());
	}

}
